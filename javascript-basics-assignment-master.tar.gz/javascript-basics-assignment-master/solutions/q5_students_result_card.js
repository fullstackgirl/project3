// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.


// Write your code here

// Create a  List of students
let studentList =[
    {name: 'Asiyath', Grammer: 75, Accounts: 90},
    {name: 'Shruthi', Grammer: 65, Accounts: 83},
    {name: 'Ridhi', Grammer: 90, Accounts: 89},
    {name: 'sushama', Grammer: 80, Accounts: 67},
    {name: 'Sahana', Grammer: 67, Accounts: 90},
    {name: 'Sajid', Grammer: 78, Accounts: 67},
    {name: 'Shailesh', Grammer: 98, Accounts: 45},
    {name: 'Apsara', Grammer: 76, Accounts: 90},
    {name: 'Suman', Grammer: 78, Accounts: 67},
    {name: 'Prakash', Grammer: 56, Accounts: 45},
    {name: 'Yadhu', Grammer: 80, Accounts: 75},
    {name: 'Sukesh', Grammer: 80, Accounts: 77},
    {name: 'Karhik', Grammer: 80, Accounts: 89},
    {name: 'Sanyal', Grammer: 80, Accounts: 67},
    {name: 'Sidh', Grammer: 80, Accounts: 90},
    {name: 'Meenakshi', Grammer: 80, Accounts: 67},
    {name: 'Kair', Grammer: 80, Accounts: 45},
    {name: 'Fas', Grammer: 80, Accounts: 90},
    {name: 'Sham', Grammer: 80, Accounts: 67},
    {name: 'Shaan', Grammer: 80, Accounts: 45},
    {name: 'Mehar', Grammer: 80, Accounts: 75},
    {name: 'Moin', Grammer: 80, Accounts: 77},
    {name: 'Ism', Grammer: 80, Accounts: 89},
    {name: 'Paiju', Grammer: 80, Accounts: 67},
    {name: 'Akshay', Grammer: 80, Accounts: 90},
    {name: 'Samariys', Grammer: 80, Accounts: 67},
    {name: 'Girisha', Grammer: 80, Accounts: 45},
    {name: 'Akkineni', Grammer: 80, Accounts: 90},
    {name: 'Ahil', Grammer: 80, Accounts: 67},
    {name: 'Akhil', Grammer: 80, Accounts: 45},
    {name: 'Akhila', Grammer: 80, Accounts: 75},
    {name: 'Nikhila', Grammer: 80, Accounts: 77},
    {name: 'Sumisha', Grammer: 80, Accounts: 89},
    {name: 'Anju', Grammer: 80, Accounts: 67},
    {name: 'Arha', Grammer: 80, Accounts: 90},
    {name: 'Adin', Grammer: 80, Accounts: 67},
    {name: 'Zeva', Grammer: 80, Accounts: 45},
    {name: 'Dhni', Grammer: 80, Accounts: 90},
    {name: 'Sneha', Grammer: 80, Accounts: 67},
    {name: 'Surendra', Grammer: 80, Accounts: 45},
    {name: 'Mehta', Grammer: 80, Accounts: 75},
    {name: 'Mahima', Grammer: 80, Accounts: 77},
    {name: 'Suri', Grammer: 80, Accounts: 89},
    {name: 'Vinod', Grammer: 80, Accounts: 67},
    {name: 'Vsma', Grammer: 80, Accounts: 90},
    {name: 'Arjun', Grammer: 80, Accounts: 67},
    {name: 'Ashwin', Grammer: 80, Accounts: 45},
    {name: 'Nikhl', Grammer: 80, Accounts: 90},
    {name: 'Nikhila', Grammer: 80, Accounts: 67},
    {name: 'Amala', Grammer: 80, Accounts: 45},
    {name: 'Vijay', Grammer: 80, Physics: 56},
    {name: 'Hari', Grammer: 80, Physics: 67},
    {name: 'Viji', Grammer: 80, Physics: 86},
    {name: 'Neha', Grammer: 76, Physics: 56},
    {name: 'Serah', Grammer: 80, Physics: 89},
    {name: 'Bella', Grammer: 87, Physics: 76},
    {name: 'Kursh', Grammer: 80, Physics: 78},
    {name: 'Abhishek kumar', Grammer: 80, Physics: 76},
    {name: 'Kaimal', Grammer: 80, Physics: 78},
    {name: 'Raj', Grammer: 80, Physics: 78},
    {name: 'Pushpa', Grammer: 80, Physics: 56},
    {name: 'Lev', Grammer: 77, Physics: 67},
    {name: 'Kev', Grammer: 80, Physics: 86},
    {name: 'Naveen', Grammer: 80, Physics: 56},
    {name: 'Pavi', Grammer: 80, Physics: 89},
    {name: 'Thara', Grammer: 80, Physics: 76},
    {name: 'Meera', Grammer: 80, Physics: 78},
    {name: 'Madhu kumar', Grammer: 80, Physics: 76},
    {name: 'Priya', Grammer: 80, Physics: 78},
    {name: 'Roshan', Grammer: 80, Physics: 78},
    {name: 'Sajil', Grammer: 87, Physics: 56},
    {name: 'Chemm', Grammer: 80, Physics: 67},
    {name: 'Nichu', Grammer: 80, Physics: 86},
    {name: 'Kevin', Grammer: 80, Physics: 56},
    {name: 'Rohit', Grammer: 80, Physics: 89},
    {name: 'Rami', Grammer: 80, Physics: 76},
    {name: 'Remya', Grammer: 80, Physics: 78},
    {name: 'Ramt kumar', Grammer: 80, Physics: 76},
    {name: 'kumari', Grammer: 80, Physics: 78},
    {name: 'kumsi', Grammer: 80, Physics: 78},
    {name: 'Mahesh', Grammer: 80, Physics: 56},
    {name: 'Naresh', Grammer: 80, Physics: 67},
    {name: 'Kamesh', Grammer: 80, Physics: 86},
    {name: 'Kalpesh', Grammer: 80, Physics: 56},
    {name: 'Rajesh', Grammer: 80, Physics: 89},
    {name: 'Nijan', Grammer: 80, Physics: 76},
    {name: 'Joseph', Grammer: 80, Physics: 78},
    {name: 'Lev kumar', Grammer: 80, Physics: 76},
    {name: 'Sukanya', Grammer: 80, Physics: 78},
    {name: 'Merin', Grammer: 80, Physics: 78},
    {name: 'Khan', Grammer: 80, Physics: 56},
    {name: 'Salman', Grammer: 80, Physics: 67},
    {name: 'Sarah', Grammer: 80, Physics: 86},
    {name: 'Ibrahim', Grammer: 80, Physics: 56},
    {name: 'Rizwan', Grammer: 80, Physics: 89},
    {name: 'Ramsi', Grammer: 80, Physics: 76},
    {name: 'Ehsan', Grammer: 80, Physics: 78},
    {name: 'Imran kumar', Grammer: 80, Physics: 76},
    {name: 'Leina', Grammer: 80, Physics: 78},
    {name: 'Laila', Grammer: 80, Physics: 78}];
// Function to print  name of the studen  and the respective percentage.    
const printPercent = (studentListItems)=> {
    console.log('Serial No'+'\t\t\t'+'Name'+'\t\t\t'+'Percentage');
    let slno =0;
    studentListItems.forEach(function (arrayItem) {
        let percentage = 0;
        if(!isNaN(arrayItem.Physics))
        {
            percentage = (arrayItem.Grammer+arrayItem.Physics)/2;
        }
        else if(!isNaN(arrayItem.Accounts))
        {
            percentage = (arrayItem.Grammer+arrayItem.Accounts)/2;
        }
        slno +=1;
       console.log(slno +'\t\t\t'+ arrayItem.name+'\t\t\t'+percentage);
    });
   };


module.exports = printPercent;
  
// Call function to print percentage
printPercent(studentList);


