

/* Write a Program to convert an array of objects to an object
	based on a given key */

// Function to fill the result object	
const fillResult = (keyName,key,arrayItem,result) => {
		if(keyName===key)
		{  
			result[arrayItem[key]]= arrayItem ;
		}
};

// Function to convert array to object based on key passed.
const convert = (array,key) => {
	let i;
	let j;

	let result = {};
	let keyNames;
	if(array instanceof Array)
	{
		for ( i=0; i<array.length; i+=1) 
		{
			keyNames = Object.keys(array[i]);
			for( j=0;j<keyNames.length;j+=1)
			{
				fillResult(keyNames[j],key,array[i],result);
			}
		}
	return result;
	}
	return null;
};


//
/* For example,
INPUT - convert([{id: 1, value: 'abc'}, {id: 2, value: 'xyz'}], 'id')
OUTPUT - {
			'1': {id: 1, value: 'abc'},
			'2': {id: 2, value: 'xyz'}
		 }
	
*/

module.exports = convert;

