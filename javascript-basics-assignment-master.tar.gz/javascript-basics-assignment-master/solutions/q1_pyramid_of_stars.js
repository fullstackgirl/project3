/* Write a program to build a `Pyramid of stars` of given height */

const buildPyramid = (n) => {
    let pyramid = '';
      
    if (isNaN(n))
    {
       // when n is not valid
    }else{
        
    for (let i = 1; i <= n; i += 1) {
        
        let row = '';
        for (let j = i; j <= n - 1; j += 1) {
            row += ' ';
        }
        for (let k = 1; k <= i; k += 1) {
            row += ' *';
        }
        pyramid += row + '  ' + '\n';
    }
    return pyramid;    
}
    return pyramid;
};

/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/

module.exports = buildPyramid;
//console.log(buildPyramid(10));

