// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast
// Write your code here

// Declare the list fo fruits
let fruitsList =[{ name:'Orange', color: 'Orange', pricePerKg: 50},
					{ name:'Avacado', color: 'Green', pricePerKg: 100},
                    { name:'Mango', color: 'Yellow', pricePerKg: 90},
                    { name:'Pomegranate', color: 'Pink', pricePerKg: 100}];

//Function to return the color and price per KG based on fruitname you pass.
 const retrieval = (fruits,fruitName)=> {
    let colorAndPrice;
    fruits.forEach(function (arrayItem) {
          if(arrayItem.name === fruitName)
        {
            colorAndPrice = 'color: '+arrayItem.color + ' price:'+arrayItem.pricePerKg;
        }
    });
    return colorAndPrice;
 };

 module.exports = retrieval;
 //Function call 
 console.log(retrieval(fruitsList,'Avacado'));
 
